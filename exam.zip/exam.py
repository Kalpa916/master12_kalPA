import pandas as pd
from csv import reader
# open file in read mode
with open("C:\Users\admin\Downloads\airlines.csv", "r") as f1:
    # pass the file object to reader() to get the reader object
    read = reader(f1)
    # Iterate over each row in the csv using reader object
    for row in read:
        # row variable is a list that represents a row in csv
        print(row)
        print(row["Airport.Name"],row["Time.Year"],row["Statistics.Flights.Cancelled"])

#using pandas library
     
import pandas as pd
  


# import pandas module
import pandas as pd
# import csv module
import csv

with open("C:\Users\admin\Downloads\airlines.csv") as csv_file:
	# read the csv file
	csv_reader = csv.reader(csv_file)

	# now we can use this csv files into the pandas
	df = pd.DataFrame([csv_reader], index = None)

# iterating values of first column
for val in list(df[1]):
	print(val)

p=df["Airport.Name"].max()
q=df["Airport.Name"].min()    
