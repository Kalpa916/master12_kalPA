from django.apps import AppConfig


class VerappConfig(AppConfig):
    name = 'verapp'
