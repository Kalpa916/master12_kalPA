from django import forms
from .models import Contact
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Layout,Submit
class ContactForm(forms.Form):
    name=forms.CharField()
    email=forms.EmailField(label='Email')
    city=forms.ChoiceField(choices=[('Hyderbad','hyd'),('Banglore','Blr'),('Chandigarh','chd')])
    address=forms.CharField(widget=forms.Textarea)
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.helper=FormHelper
        self.helper.form_method='post'
        self.helper.layout=Layout(
        'name',
        'email',
        'city',
        'address',
        Submit('submit','SUBMIT',css_class='btn_success')
        )
class ContactForm1(forms.ModelForm):
    class Meta:
        model=Contact
        fields=('name','biodata')
