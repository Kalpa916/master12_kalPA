from django.shortcuts import render


# Create your views here.
from .forms import ContactForm,ContactForm1
def input(request):
    if (request.method=='POST'):
        form=ContactForm(request.POST)
        if (form.is_valid()):
            name=form.cleaned_data['name']
            email=form.cleaned_data['email']
            city=form.cleaned_data['city']
            address=form.cleaned_data['address']
            print(name,email,city,address)
    form=ContactForm()
    return render(request,'base.html',{'form':form})
def input_details(request):
    if (request.method=='POST'):
        form1=ContactForm1(request.POST)
        if (form1.is_valid()):
            form1.save()
    else:
        form1=ContactForm1()
    return render(request,'base.html',{'form':form1})
