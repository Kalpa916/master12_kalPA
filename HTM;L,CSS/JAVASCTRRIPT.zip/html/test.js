/* example on creating external js file */
function fun1()
{
  document.write("hi, im fun1");
}

function fun2()
{
  document.write("hi, im fun2");
}

//save this file with a name "test.js"