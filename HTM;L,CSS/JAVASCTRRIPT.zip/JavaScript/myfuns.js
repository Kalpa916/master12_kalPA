//example on user define functions
function fun1()
{
  document.write("hi, im fun1<br>");
}

function fun2()
{
  document.write("hi, im fun2<br>");
}

//save this file with a name "myfuns.js"