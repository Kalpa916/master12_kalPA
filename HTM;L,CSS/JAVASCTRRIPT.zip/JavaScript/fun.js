//external functions

	function myFun(a, b)   //FA with def value
	{
	  document.write( a + ': ' + b +"<br>");
	}
