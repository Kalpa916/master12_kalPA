//example on external function with default values

	function myFun(a, b="Hi")   //FA with def value
	{
	  document.write( a + ': ' + b +"<br>");
	}

/* some more ex:
    function myFun2(a="S", b)  <== valid
	function myFun3(x, y=20, z)  <== valid
	function myFun4(a="S", b="Hi") <== valid
*/

//funs.js